/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
	int hours, minutes, seconds, totaltime;

	printf("Enter hours minutes seconds :");
	scanf("%d%d%d", &hours,& minutes, &seconds);

	totaltime = hours * 3600 + minutes * 60 + seconds;
	printf("Total time = %d", totaltime);


	return 0;
}
