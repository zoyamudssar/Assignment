/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
	float mm, inches;
	printf("Enter millimeters :");
	scanf("%f", &mm);

	inches = mm / 25.4;

	printf("Inches = %f", inches);

	return 0;
}