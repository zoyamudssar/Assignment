/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
	int roll, pf, ic, cg, total;
	float average;
	printf("Enter roll no :");
	scanf("%d", &roll);
	printf("Enter marks of pf, ic, cg :");
	scanf("%d%d%d",&pf, &ic, &cg);

	total = pf + ic + cg;
	average = total / 3.0;
	printf("Total = %d\nAverage = %d", total, average);
	return 0;
}
