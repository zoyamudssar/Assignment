/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
	float a, b, c, s, area;
	printf("Enter three sides :");
	scanf("%f%f%f", &a, &b, &c);
	s = (a + b + c) / 2;
	area = (s * (s-a) * (s-b) * (s-c));
	printf("Area = %f", area);

	return 0;
}
